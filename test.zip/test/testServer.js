const express = require("express");
const axios = require("axios");
const cors = require("cors");
require("dotenv").config();

const app = express();

// 미들웨어 설정
app.use(cors());
app.use(express.static("public"));
app.use(express.json());

// 대화 컨텍스트 관리
class ConversationManager {
  constructor(maxMessages = 10) {
    this.conversations = new Map();
    this.maxMessages = maxMessages;
  }

  getConversation(userId) {
    if (!this.conversations.has(userId)) {
      this.conversations.set(userId, [
        { role: "system", content: "당신은 사용자의 위치 질문에 정확하고 친절하게 답변하는 AI 어시스턴트입니다." }
      ]);
    }
    return this.conversations.get(userId);
  }

  addMessage(userId, role, content) {
    const conversation = this.getConversation(userId);
    conversation.push({ role, content });
    if (conversation.length > this.maxMessages + 1) {
      conversation.splice(1, 1);
    }
    return conversation;
  }
}

const conversationManager = new ConversationManager();

async function getChatGPTResponse(messages) {
  try {
    const gptResponse = await axios.post(
      "https://api.openai.com/v1/chat/completions",
      {
        model: "gpt-3.5-turbo",
        messages: messages,
        max_tokens: 300,
        temperature: 0.7,
      },
      {
        headers: {
          "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
          "Content-Type": "application/json",
        },
      }
    );
    const content = gptResponse.data.choices?.[0]?.message?.content?.trim();
    return content || "AI 서비스에 문제가 발생했습니다.";
  } catch (error) {
    return "AI 서비스에 문제가 발생했습니다.";
  }
}

// 장소 검색 함수
async function searchPlaces(query) {
  try {
    const mapsResponse = await axios.get(
      `https://maps.googleapis.com/maps/api/place/textsearch/json`,
      {
        params: {
          key: process.env.GOOGLE_MAPS_API_KEY,
          query: query,
          language: 'ko',
          type: 'point_of_interest',
          radius: 10000
        },
      }
    );

    const places = mapsResponse.data.results.slice(0, 3).map(place => ({
      name: place.name,
      address: place.formatted_address,
      rating: place.rating || '평점 없음',
      total_ratings: place.user_ratings_total || 0,
      location: place.geometry.location,
      photo_reference: place.photos ? place.photos[0].photo_reference : ''
    }));

    return places;
  } catch (error) {
    return [];
  }
}

// 채팅 엔드포인트
app.post("/chat", async (req, res) => {
  const { message, userId = 'default' } = req.body;

  try {
    const updatedConversation = conversationManager.addMessage(userId, "user", message);
    const botResponse = await getChatGPTResponse(updatedConversation);
    conversationManager.addMessage(userId, "assistant", botResponse);

    const locationKeywords = ['맛집', '숙소', '위치', '장소', '근처', '어디'];
    const isLocationQuery = locationKeywords.some(keyword => message.includes(keyword));

    let places = [];
    if (isLocationQuery) {
      places = await searchPlaces(message);
    }

    const placeDetails = places.map(place => ({
      name: place.name,
      address: place.address,
      location: place.location,
      photo_reference: place.photo_reference
    }));

    res.json({
      message: botResponse,
      places: placeDetails
    });
  } catch (error) {
    res.status(500).json({ message: "서버 오류가 발생했습니다.", error: error.message });
  }
});

// Google Maps API 키 제공 엔드포인트
app.get("/getGoogleMapsApiKey", (req, res) => {
  res.json({ googleMapsApiKey: process.env.GOOGLE_MAPS_API_KEY });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`서버가 http://localhost:${PORT} 에서 실행 중입니다.`);
});