// routes/chatRoutes.js
const express = require('express');
const { OpenAI } = require('openai');  // OpenAI 객체 불러오기
require('dotenv').config(); // .env 파일에서 환경 변수 로드

const router = express.Router();

// OpenAI API 초기화
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,  // API 키는 환경변수에서 가져옴
});

router.post('/', async (req, res) => {
  const { message } = req.body;

  if (!message) {
    return res.status(400).send({ error: 'Message is required' });
  }

  try {
    // OpenAI API 호출 (GPT-4 모델 사용)
    const response = await openai.chat.completions.create({
      model: 'gpt-4',  // 또는 'gpt-3.5-turbo'
      messages: [{ role: 'user', content: message }],
    });

    // 응답 데이터에서 메시지 내용 추출
    const reply = response.choices[0].message.content;
    res.send({ reply }); // 클라이언트에 답변 전송
  } catch (error) {
    console.error('OpenAI API Error:', error);
    res.status(500).send({ error: 'Failed to communicate with OpenAI API' });
  }
});

module.exports = router;
