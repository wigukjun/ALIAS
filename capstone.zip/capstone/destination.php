<?php
// Database connection details
$servername = "localhost"; // Typically 'localhost' in XAMPP
$username = "root"; // Default username for XAMPP
$password = ""; // Default password is empty for XAMPP
$dbname = "test"; // Database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get data from the form
    $nation = $_POST['NATION'];
    $place = $_POST['PLACE'];

    // Prepare the SQL query
    $sql = "INSERT INTO destination (nation, place) VALUES (?, ?)";

    // Prepare and bind
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $nation, $place); // "ss" means both are strings

    // Execute the query and check if insertion is successful
    if ($stmt->execute()) {
        echo "Data successfully uploaded!";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the prepared statement and connection
    $stmt->close();
}

// Close connection
$conn->close();
?>