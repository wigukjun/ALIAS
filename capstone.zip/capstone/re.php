<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>예약하기</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            padding: 20px;
        }
        .container {
            width: 400px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            font-size: 16px;
            color: #333;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border-radius: 8px;
            border: 1px solid #ddd;
        }
        .form-group button {
            width: 100%;
            padding: 12px;
            background-color: #4e89ae;
            color: white;
            border: none;
            font-size: 16px;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .form-group button:hover {
            background-color: #357fa5;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>예약하기</h2>
        <form action="reserve.php" method="POST">
            <div class="form-group">
                <label for="name">이름</label>
                <input type="text" id="name" name="name" required placeholder="이름을 입력하세요">
            </div>
            <div class="form-group">
                <label for="user_id">아이디</label>
                <input type="text" id="user_id" name="user_id" required placeholder="아이디를 입력하세요">
            </div>
            <input type="hidden" name="place_id" value="<?php echo $_GET['place_id']; ?>"> <!-- place_id 전달 -->
            <div class="form-group">
                <button type="submit">예약 완료</button>
            </div>
        </form>
    </div>
</body>
</html>