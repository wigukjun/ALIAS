<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // MySQL 데이터베이스 연결 설정
    $servername = "localhost";
    $username = "root"; // XAMPP 기본 사용자
    $password = ""; // XAMPP 기본 비밀번호는 빈값
    $dbname = "test";

    // 입력된 데이터 가져오기
    $userId = $_POST['id'];
    $userPw = $_POST['pw'];

    // 데이터베이스 연결
    $conn = new mysqli($servername, $username, $password, $dbname);

    // 연결 오류 확인
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // SELECT 쿼리로 ID와 비밀번호 확인
    $sql = "SELECT * FROM jointable WHERE id = ? AND password = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $userId, $userPw);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "<script>alert('로그인에 성공하였습니다.'); window.location.href='mainpage.html';</script>";
    } else {
        echo "<script>alert('로그인에 실패하였습니다.'); window.history.back();</script>";
    }

    // 연결 종료
    $stmt->close();
    $conn->close();
}
?>
