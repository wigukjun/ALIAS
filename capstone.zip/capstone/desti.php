<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>여행국가 및 목적지 입력</title>
    <link href="style.css" rel="stylesheet" type="text/css">
    <script src="script.js" type="text/javascript"></script>
</head>
<body>
    <section class="destination-form">
        <h1>TRAVEL INFORMATION</h1>
        <form action="destination.php" method="POST">
            <div class="int-area">
                <input type="text" name="NATION" id="nation" autocomplete="off" required>
                <label for="nation">NATION</label>
            </div>
            <div class="int-area">
                <input type="text" name="PLACE" id="place" autocomplete="off" required>
                <label for="place">PLACE</label>
            </div>
            <div class="btn-area">
                <button type="submit">SUBMIT</button>
            </div>
    </section>
</body>
</html>