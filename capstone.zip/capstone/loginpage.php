<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>로그인</title>
    <link href="loginstyle.css" rel="stylesheet" type="text/css">
    <script src="script2.js" type="text/javascript"></script>
</head>
<body>
    <section class="login-form">
        <h1>로그인</h1>
        <form action="login.php" method="POST"> <!-- action에 login.php 추가 -->
            <div class="int-area">
                <input type="text" name="id" id="id" autocomplete="off" required>
                <label for="id">아이디</label>
            </div>
            <div class="int-area">
                <input type="password" name="pw" id="pw" autocomplete="off" required>
                <label for="pw">비밀번호</label>
            </div>
            <div class="btn-area">
                <button type="submit">로그인</button> <!-- type을 submit으로 설정 -->
            </div>
        </form>
        <div class="caption">
            <a href="#">비밀번호를 잊어버리셨습니까?</a>
        </div>
    </section>
</body>
</html>
