<?php
// 데이터베이스 연결 설정
$host = 'localhost';  // MySQL 서버 주소
$username = 'root';   // MySQL 사용자명
$password = '';       // MySQL 비밀번호
$dbname = 'test'; // 사용할 데이터베이스 이름

// 데이터베이스 연결
$conn = new mysqli($host, $username, $password, $dbname);

// 연결 오류가 있는 경우 처리
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// 폼에서 전달된 데이터 받기
$name = $_POST['name'];      // 사용자가 입력한 이름
$user_id = $_POST['user_id']; // 사용자가 입력한 아이디
$place_id = $_POST['place_id']; // 선택된 장소 ID

// 예약 정보를 데이터베이스에 삽입
$sql = "INSERT INTO reservations (user_name, user_id, place_id) VALUES ('$name', '$user_id', '$place_id')";

// 쿼리 실행
if ($conn->query($sql) === TRUE) {
    // 예약 완료 메시지 출력
    echo "<h2>예약이 완료되었습니다!</h2>";
    echo "<p>이름: $name</p>";
    echo "<p>아이디: $user_id</p>";
    echo "<p>장소 ID: $place_id</p>";
    echo "<a href='mainpage.html'>홈으로 돌아가기</a>";  // 홈 페이지로 돌아가는 링크
} else {
    // 오류 메시지 출력
    echo "오류 발생: " . $conn->error;
}

// 데이터베이스 연결 종료
$conn->close();
?>