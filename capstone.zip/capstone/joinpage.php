<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>회원가입</title>
    <link href="style2.css" rel="stylesheet" type="text/css">
    <script src="script2.js" type="text/javascript"></script>
</head>
<body>
    <section class="login-form">    
        <h1>회원가입</h1>
        <form action="join.php" method="post"> 
            <div class="int-area">
                <input type="text" name="id" id="id" autocomplete="off" required>
                <label for="id">아이디</label>
            </div>
            <div class="int-area">
                <input type="password" name="pw" id="pw" autocomplete="off" required>
                <label for="pw">비밀번호</label>
            </div>
            <div class="btn-area">
                <button type="submit">가입하기</button>
            </div>
        </form>
    </section>
</body>
</html>